<?php
/**
 * Plugin Name: Practicas Profesionales API Client
 * Plugin URI: https://github.com/hmnoscarrillo/gestion-practicas-api
 * Description: Consume la API REST de Gestion de Practicas Profesionales desplegada en Railway y muestra los datos en tiempo real mediante el shortcode [practicas_api].
 * Version: 1.0.0
 * Author: Ivan Carrillo
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit;
}

function practicas_api_render_shortcode($atts) {
    // URL base de la API (desde wp-config.php o valor por defecto de Railway)
    $api_base = defined('PRACTICAS_API_BASE_URL') ? untrailingslashit(PRACTICAS_API_BASE_URL) : 'https://api-gestion-practicas-production.up.railway.app';
    $endpoint = $api_base . '/api/practicas/getPracticas';

    // Realizar solicitud HTTP GET a la API en Railway
    $response = wp_remote_get($endpoint, array(
        'timeout' => 10,
        'headers' => array(
            'Accept' => 'application/json'
        )
    ));

    if (is_wp_error($response)) {
        return '<div class="practicas-api-container"><p style="color: #dc2626; padding: 15px; background: #fee2e2; border-radius: 8px;"><strong>Error de conexion con la API:</strong> ' . esc_html($response->get_error_message()) . '</p></div>';
    }

    $status_code = wp_remote_retrieve_response_code($response);
    if ($status_code !== 200) {
        return '<div class="practicas-api-container"><p style="color: #dc2626; padding: 15px; background: #fee2e2; border-radius: 8px;"><strong>Error en el servidor de la API:</strong> Codigo de respuesta HTTP ' . esc_html($status_code) . '</p></div>';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (empty($data['success']) || !isset($data['data']) || !is_array($data['data'])) {
        return '<div class="practicas-api-container"><p style="color: #d97706; padding: 15px; background: #fef3c7; border-radius: 8px;">No se encontraron registros de practicas disponibles en este momento.</p></div>';
    }

    $practicas = $data['data'];
    $total = count($practicas);
    $total_horas = array_sum(array_column($practicas, 'horas_totales'));
    $promedio_horas = $total > 0 ? round($total_horas / $total) : 0;

    ob_start();
    ?>
    <div class="practicas-api-container">
        <!-- Indicador de conexion activa en la nube -->
        <div class="practicas-api-badge-railway">
            <span class="dot"></span>
            <span>API REST Cloud Conectada: Railway (MySQL en vivo)</span>
        </div>

        <!-- Tarjetas resumen de metricas -->
        <div class="practicas-api-stats-grid">
            <div class="practicas-api-stat-card">
                <div class="practicas-api-stat-title">Practicas Activas</div>
                <div class="practicas-api-stat-value"><?php echo esc_html($total); ?></div>
            </div>
            <div class="practicas-api-stat-card">
                <div class="practicas-api-stat-title">Estudiantes Vinculados</div>
                <div class="practicas-api-stat-value"><?php echo esc_html($total); ?></div>
            </div>
            <div class="practicas-api-stat-card">
                <div class="practicas-api-stat-title">Horas Promedio</div>
                <div class="practicas-api-stat-value"><?php echo esc_html($promedio_horas); ?> hrs</div>
            </div>
            <div class="practicas-api-stat-card">
                <div class="practicas-api-stat-title">Disponibilidad Cloud</div>
                <div class="practicas-api-stat-value" style="color: #059669;">100%</div>
            </div>
        </div>

        <!-- Tabla organizada y responsive -->
        <div class="practicas-api-table-wrapper">
            <table class="practicas-api-table">
                <thead>
                    <tr>
                        <th>Codigo</th>
                        <th>Estudiante</th>
                        <th>Empresa</th>
                        <th>Programa Academico</th>
                        <th>Cargo Asignado</th>
                        <th>Modalidad</th>
                        <th>Horas</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($practicas as $item): ?>
                        <?php 
                            $mod = strtolower($item['modalidad'] ?? 'presencial');
                            $tag_mod_class = 'practicas-tag-' . ($mod === 'hibrido' ? 'hibrido' : ($mod === 'remoto' ? 'remoto' : 'presencial'));
                            $estado = strtolower($item['estado'] ?? 'en curso');
                            $tag_est_class = 'practicas-tag-' . ($estado === 'en curso' ? 'encurso' : 'finalizada');
                        ?>
                        <tr>
                            <td data-label="Codigo"><strong><?php echo esc_html($item['codigo_practica']); ?></strong></td>
                            <td data-label="Estudiante">
                                <div><?php echo esc_html($item['estudiante_nombre']); ?></div>
                                <div class="practicas-subtext">Doc: <?php echo esc_html($item['estudiante_documento'] ?? 'N/A'); ?></div>
                            </td>
                            <td data-label="Empresa">
                                <div><?php echo esc_html($item['empresa_nombre']); ?></div>
                                <div class="practicas-subtext">NIT: <?php echo esc_html($item['empresa_nit'] ?? 'N/A'); ?></div>
                            </td>
                            <td data-label="Programa"><?php echo esc_html($item['programa_nombre']); ?></td>
                            <td data-label="Cargo"><?php echo esc_html($item['cargo_practicante']); ?></td>
                            <td data-label="Modalidad">
                                <span class="practicas-tag <?php echo esc_attr($tag_mod_class); ?>">
                                    <?php echo esc_html($item['modalidad']); ?>
                                </span>
                            </td>
                            <td data-label="Horas"><?php echo esc_html($item['horas_totales']); ?> h</td>
                            <td data-label="Estado">
                                <span class="practicas-tag <?php echo esc_attr($tag_est_class); ?>">
                                    <?php echo esc_html($item['estado']); ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('practicas_api', 'practicas_api_render_shortcode');

function practicas_api_enqueue_assets() {
    wp_register_style('practicas-api-style', plugin_dir_url(__FILE__) . 'practicas-api.css', array(), '1.0.0');
    wp_enqueue_style('practicas-api-style');
}
add_action('wp_enqueue_scripts', 'practicas_api_enqueue_assets');
